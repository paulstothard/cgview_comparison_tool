/*
 * $Id: mapcn3d.h,v 1.1 2001/06/21 13:02:28 thiessen Exp $
 *
 * Headers needed for objcn3d.c
 */

#include <objall.h>
#include <objmmdb1.h>
