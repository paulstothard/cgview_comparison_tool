#ifndef __MODULE_utilpub__
#define __MODULE_utilpub__

#define ERR_QUALIFIER  1,0
#define ERR_QUALIFIER_NoRefForCiteQual  1,1

#endif
